//
//  WeatherModel.m
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 13/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import "WeatherModel.h"

@implementation WeatherModel


-(id) initWithDictionary:(NSDictionary *)dict {
    
    
    self = [super init];
    
    if(self){
        
        
        _dict = dict;
        
    }
    
    return self;
    
}





@end
