//
//  SecondViewController.h
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 12/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "UIKit+AFNetworking.h"
@interface SecondViewController : UIViewController  <UITableViewDataSource>



@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) NSArray *weekDayArray;
@property (nonatomic, strong) IBOutlet UIViewController *destViewController;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
