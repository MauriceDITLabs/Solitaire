//
//  main.m
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 11/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
