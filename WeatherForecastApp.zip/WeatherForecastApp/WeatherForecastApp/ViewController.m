//
//  ViewController.m
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 11/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)fiveDayForecast:(id)sender {

   void (^callBackBlock)(NSArray*) = ^(NSArray * array) {
        
        
        
        [self performSegueWithIdentifier:@"mySegue" sender:sender];
      
        
    };
    
    NSString * search = _searchField.text;
    
    
  
    NSString * weather = [NSString stringWithFormat:@"http://openweathermap.org/data/2.5/forecast/daily?q=%@ &mode=json&units=metric&cnt=5&APPID=88eeed22545d24062681613fdeec8d53" ,search];
    
    
 
    NSString * connection = weather;
   
    
    NSURL *url = [NSURL URLWithString:weather];
    

    
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    
    
    NSString *encoded = [weather stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    
    AFHTTPRequestOperationManager *ipaddress = [[AFHTTPRequestOperationManager alloc] init];
    
    [ipaddress GET:encoded
        parameters:nil
     
    success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSDictionary *dictionary = (NSDictionary *) responseObject;
               
               
               NSLog(@"%@ The key is", dictionary[@"ip"]);
               
               _dailyForecast = dictionary[@"list"];
               
               
               _weatherArray = [_dailyForecast valueForKey:@"weather"];
               
               
            
               NSDateFormatter *weekday = [[NSDateFormatter alloc] init];
               [weekday setDateFormat:@"EEEE"];
               
               NSMutableArray * array2;
               
               NSNumber * num;
               
               
               array2 = [[NSMutableArray alloc] init];
               
               for(NSDictionary *dict in _dailyForecast){
                   
                   
                   
                   
                   
                   
                   num = [dict objectForKey:@"dt"];
                   
                   
                   float num2 = [num floatValue];
                   
                   
                   
                   NSDate *date2 = [NSDate dateWithTimeIntervalSince1970:num2];
                   
                   
                   NSString *day = [weekday stringFromDate:date2];
                   
                   [array2 addObject:day];
                   
                   
                   
               }
               
               
               _dayArray = array2;
               
        
               callBackBlock(_dayArray);
               
           }
     
     
           failure:nil];
  
    
  
    


}











-(BOOL) shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    
    
    if([identifier isEqualToString:@"mySegue"]){
        
        
        return YES;
        
    }
    return NO;
}


-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
   // if(_dayArray){
        
       
        
        SecondViewController *destViewController = segue.destinationViewController;
       destViewController.dataArray = _weatherArray;
        destViewController.weekDayArray = _dayArray;
    
   //}
}


- (IBAction)conditionButton:(id)sender {


    
    
    NSString * search = _searchField.text;
    
    
    
    NSString * weather = [NSString stringWithFormat:@"http://openweathermap.org/data/2.5/weather?q=%@&APPID=88eeed22545d24062681613fdeec8d53" ,search];
    

     NSString *encoded = [weather stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];


    AFHTTPRequestOperationManager *ipaddress = [[AFHTTPRequestOperationManager alloc] init ];
    
    
    [ipaddress GET: encoded
        parameters:nil
           success:^(AFHTTPRequestOperation *operation, id responseObject) {
               NSDictionary *dictionary = (NSDictionary *) responseObject;
               
               _dailyForecast = dictionary[@"list"];
               
               
               
               
               WeatherModel *modelData = [[WeatherModel alloc] initWithDictionary:dictionary];
               
               _model = modelData;
               
               
               NSDictionary * dict = _model.dict[@"main"];
               
               _tempLabel.text =  [NSString stringWithFormat:@"%@", dict[@"temp"]];
               _humLabel.text =  [NSString stringWithFormat:@"%@",  dict [@"humidity"]];
               
               NSDictionary *dict1 = _model.dict[@"wind"];
               
               _windSpeedLabel.text = [NSString stringWithFormat:@"%@" ,dict1[@"speed"]];
               
               
               _weatherArray = _model.dict[@"weather"];
               
               
               NSDictionary *icon = [_weatherArray objectAtIndex:0];
               
               NSString *iconText = icon[@"icon"];
               
               
               NSString *exten =@".png";

           
           
           
               NSString * stringImage = [NSString stringWithFormat:@"http://openweathermap.org/img/w/%@%@",iconText,exten];
               
               
               NSURL *url = [NSURL URLWithString:stringImage];
               
               NSData *data = [[NSData alloc] initWithContentsOfURL:url];
               
               UIImage *tmpImage = [[UIImage alloc] initWithData:data];
               
              _conditionDisplay.image = tmpImage;
               
               
               

           
           
           }
     
     
           failure:nil];
    
    
    
    




}







@end


















