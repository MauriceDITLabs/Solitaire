//
//  WeatherModel.h
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 13/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherModel : NSObject

@property (nonatomic, strong) NSDictionary *dict;


-(id) initWithDictionary:(NSDictionary *)dict;


@end
