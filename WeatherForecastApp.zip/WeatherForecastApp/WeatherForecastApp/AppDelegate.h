//
//  AppDelegate.h
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 11/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

