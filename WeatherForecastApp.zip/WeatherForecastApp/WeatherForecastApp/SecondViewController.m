//
//  SecondViewController.m
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 12/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    
       
    [_tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"simpleCell"];
    
    _tableView.dataSource = self;

    


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _weekDayArray.count;
    
}









- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"simpleCell"];
    
    NSArray *array = [_dataArray objectAtIndex:indexPath.row];
    
    NSDictionary *dict = [array objectAtIndex:0];
    
    NSString *icon = dict[@"icon"];
    
    NSString *exten =@".png";
    
       NSString * dayw = [_weekDayArray objectAtIndex:indexPath.row];
    
    
    
    
    
   
    NSString *forecast = [NSString stringWithFormat:@"%@  %@", dayw, dict[@"main"]];
    
    cell.textLabel.text = forecast;
    
    
    NSString * stringImage = [NSString stringWithFormat:@"http://openweathermap.org/img/w/%@%@",icon,exten];
    
    
    NSLog(@"%@", dict[@"main"]);
    
    NSURL *url = [NSURL URLWithString:stringImage];
    
    
    
    
    [cell.imageView setImageWithURL:url placeholderImage:[UIImage imageNamed:@"Test.png"]];
    
    
    
    
    
    
    
    
    return cell;
    
    
    
}















@end
