//
//  ViewController.h
//  WeatherForecastApp
//
//  Created by Maurice Kennedy on 11/02/2015.
//  Copyright (c) 2015 Maurice Kennedy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "UIKit+AFNetworking.h"
#import "SecondViewController.h"
#import "WeatherModel.h"
@interface ViewController : UIViewController
@property (nonatomic,strong) NSArray * dailyForecast;
@property (nonatomic, strong) NSArray * weatherArray;
@property (nonatomic, strong) NSArray * dayArray;

@property (weak, nonatomic) IBOutlet UITextField *searchField;

@property (weak, nonatomic) IBOutlet UILabel *tempLabel;
@property (weak, nonatomic) IBOutlet UILabel *humLabel;

@property (weak, nonatomic) IBOutlet UILabel *windSpeedLabel;

@property (weak, nonatomic) IBOutlet UIImageView *conditionDisplay;

@property (nonatomic, strong) WeatherModel * model;



@end

